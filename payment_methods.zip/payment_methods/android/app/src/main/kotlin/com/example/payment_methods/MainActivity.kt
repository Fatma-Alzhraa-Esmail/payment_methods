package com.example.payment_methods

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
